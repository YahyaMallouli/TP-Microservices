package com.example.microimp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MicroImpApplicationTests {

    @Test
    void contextLoads() {
    }

}
